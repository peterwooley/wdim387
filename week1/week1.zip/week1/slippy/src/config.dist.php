<?php

// directory where the slide decks are placed (*.html is scanned)
$dir = dirname(__FILE__);

// the php template that will render the base repository page
$repositoryTemplate = 'repo.php';